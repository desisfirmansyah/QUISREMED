/**
 *
 * @author JARVIS
 * nama : DESIS FIRMANSYAH
 * nim  : 10116075
 * kelas: PBO ULANG - 3
 */
package quis_desis;

import java.util.Scanner;

/**
 *
 * @author JARVIS
 */
interface ServiceItem {
    ServicePrice serviceprice = new ServicePrice();
    
    public void displayService();
    public float getPrice(int serviceitem);
    public boolean checkMemberStatus(String statusMember);
    public float getSale(boolean isMember,float parServicePrice);
    
   
}
