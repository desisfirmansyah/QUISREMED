/**
 *
 * @author JARVIS
 * nama : DESIS FIRMANSYAH
 * nim  : 10116075
 * kelas: PBO ULANG - 3
 */
package quis_desis;

import java.util.Scanner;

/**
 *
 * @author JARVIS
 * nama : DESIS FIRMANSYAH
 * nim  : 10116075
 * kelas: PBO ULANG - 3
 */
public class Quis_DESIS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServicePrice serviceprice = new ServicePrice();
        String statusMember;
        Scanner sc = new Scanner(System.in);
        System.out.print("Nama Anda : ");
        String name = sc.next();
        serviceprice.customer.setName(name);
        serviceprice.customer.getName();
        System.out.print("Email Anda : ");
        String email = sc.next();
        serviceprice.customer.setEmail(email);
        serviceprice.customer.getEmail();
        serviceprice.displayService();
        System.out.print("Member ? (n/y):  ");
        statusMember = sc.next();
        System.out.println("");
        System.out.println("#*************************# ");
        System.out.println("#****Customer Invoice*****# ");
        System.out.println("waktu sekarang : "+serviceprice.customer.currentTime());
        serviceprice.setPriceService(serviceprice.getPriceService());
        //System.out.println("discount : "+serviceprice.getSale((int) serviceitem));

        System.out.println("discount : "+serviceprice.getSale(serviceprice.checkMemberStatus("y"), serviceprice.getPrice((int) serviceprice.serviceitem)));
        System.out.println("total pay : "+serviceprice.getTotalPay(serviceprice.getPrice((int) serviceprice.serviceitem), serviceprice.getSale(serviceprice.checkMemberStatus("y"), serviceprice.getPrice((int) serviceprice.serviceitem))));
        
        
        
    }
    
}
