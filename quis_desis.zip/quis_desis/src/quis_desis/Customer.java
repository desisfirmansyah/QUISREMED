/**
 *
 * @author JARVIS
 * nama : DESIS FIRMANSYAH
 * nim  : 10116075
 * kelas: PBO ULANG- 3
 */
package quis_desis;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
/**
 *
 * @author JARVIS
 */

public class Customer {
    private String name;
    private String email;
    private boolean member;
    
   
    //Customerinvoice dattee = new Customerinvoice() {};
    
    public String getName(){
        
        this.name = name;
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getEmail(){
        this.email = email;
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public boolean isMember(){
      
        return true;
    }
    public void setMember(boolean member){
        
        this.member = member;
    }
    public String currentTime(){
        String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        return date;
    }
   
}
