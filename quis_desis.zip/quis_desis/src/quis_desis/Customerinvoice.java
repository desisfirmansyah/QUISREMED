/**
 *
 * @author JARVIS
 * nama : DESIS FIRMANSYAH
 * nim  : 10116075
 * kelas: PBO ULANG - 3
 */
package quis_desis;


/**
 *
 * @author JARVIS
 */
interface Customerinvoice {
    Customer customer = new Customer();
    public String currentTime();
  
}
