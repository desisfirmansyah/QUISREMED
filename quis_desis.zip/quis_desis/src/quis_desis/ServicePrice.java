/**
 *
 * @author JARVIS
 * nama : DESIS FIRMANSYAH
 * nim  : 10116075
 * kelas: PBO ULANG- 3
 */
package quis_desis;

import java.util.Scanner;

/**
 *
 * @author JARVIS
 */
public class ServicePrice {
    Customer customer = new Customer();
    private float priceService;
    private float discount;
    float serviceitem = 0;
    
    
    
   
    public float getPriceService(){
        priceService = 0;
        if(serviceitem == 1){
            priceService = 45000;
            serviceitem = priceService;
        }else if (serviceitem == 2){
            priceService = 55000;
            serviceitem = priceService;
        }else if(serviceitem == 3){
            priceService = 15000;
            serviceitem = priceService;
        }else {
            priceService = 0;
            serviceitem = priceService;
        }
        return serviceitem;
    }
    
    public void setPriceService(float priceService){
       System.out.println("Service Price : "+getPrice((int) serviceitem));
    }
    
    public void displayService(){
        Scanner sc = new Scanner(System.in);
        System.out.println("#*************************# ");
        System.out.println("#***Rock n Roll Haircut***# ");
        System.out.println("#*******Service List******# ");
        System.out.println("1. Haircut : IDR 45K ");
        System.out.println("2. Haircut + Hairwash: IDR 55K ");
        System.out.println("3. Hairwash Only : IDR 15K  ");
        System.out.println("#*************************# ");
        System.out.print("Choose (1/2/3):  ");
        serviceitem = sc.nextInt();

    }
    
    public float getPrice(int serviceitem){
        return priceService;
    }
    
    public boolean checkMemberStatus(String statusMember){
        
        if(statusMember=="y"){
            return true;
        }else{
            return false;
        }
    }
    
    
    public float getSale(boolean isMember, float parServicePrice){
        
        if(isMember ){
            discount = (float) (0.10*parServicePrice);
        }else{
            discount = 0;
        }
        return discount;
    }
    
    public float getTotalPay(float priceService, float discount){
        float Total = 0;
        if(discount>0){
            Total = priceService - discount;
        }else{
            Total = priceService;
        }
        return Total;
    }
    
    
}
